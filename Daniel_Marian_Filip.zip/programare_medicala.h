/*
 * TODO:
 * Vizualizati fisierul programare_medicala.c
 */