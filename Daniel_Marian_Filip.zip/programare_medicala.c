/*
 * TODO:
 * - [ ] Implementare structura pentru pacienti
 * - [ ] Implementare structura pentru medici
 * - [ ] Implementare structura pentru programari
 * - [ ] Implementare structura pentru consultatii
 * - [ ] Implementare programari medicale
 * - [ ] Implementare consultatii medicale
 * - [ ] Implementare rapoarte medicale
 * - [ ] Implementare fisiere pentru salvarea datelor
 * - [ ] Implementare interfata grafica pentru utilizator
 */